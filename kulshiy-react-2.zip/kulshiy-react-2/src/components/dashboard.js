import React, { useEffect } from 'react';
import './Dashboard.css'; 
import { useAuth } from './AuthContext.js';

function Dashboard() {
  const { logout, user, fetchUserData } = useAuth();

  useEffect(() => {
    // Poll for user data every 10 seconds
    const intervalId = setInterval(() => {
      fetchUserData();
    }, 10000); // 10 seconds

    // Fetch user data initially
    fetchUserData();

    // Clear the interval on component unmount
    return () => clearInterval(intervalId);
  }, [fetchUserData]);

  return (
    <div className="dashboard-container">
      <h2 className="dashboard-title">User Information</h2>
      <table className="dashboard-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile No</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{user?.name}</td>
            <td>{user?.email}</td>
            <td>{user?.mobile}</td>
          </tr>
        </tbody>
      </table>

      <div className="logout-button-container">
        <button className="logout-button" onClick={logout}>
          log out
        </button>
      </div>
    </div>
  );
}

export default Dashboard;
