import React, { useState } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext.js';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const { login } = useAuth();

  const handleSubmit = async (e) => { 
    e.preventDefault();
    try {
      const res = await axios.post('https://kulshiy.com/staging/api/store-login', {
        email: email,
        password: password
      });

      if (res.status === 200) {
        setMessage('Login successful');
        login(res.data); // Pass the user data to the login function
      } else {
        setMessage(res.data.message || 'Some error occurred');
      }
    } catch (err) {
      console.log(err);
      setMessage('Server error');
    }
  };

  return (
    <div id="login">
      <h3 className="text-center text-white pt-5">Login form</h3>
      <div className="container">
        <div id="login-row" className="row justify-content-center align-items-center">
          <div id="login-column" className="col-md-6">
            <div id="login-box" className="col-md-12">
              <form id="login-form" className="form" onSubmit={handleSubmit}>
                <h3 className="text-center text-info">Login</h3>
                <div className="form-group">
                  <label htmlFor="email" className="text-info">Email:</label><br />
                  <input 
                    type="text" 
                    name="email" 
                    id="email" 
                    className="form-control" 
                    onChange={(e) => setEmail(e.target.value)} 
                    value={email}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="password" className="text-info">Password:</label><br />
                  <input 
                    type="password" 
                    name="password" 
                    id="password" 
                    className="form-control" 
                    onChange={(e) => setPassword(e.target.value)} 
                    value={password}
                  />
                </div>
                <br />
                <div className="form-group">
                  <input id="remember-me" name="remember-me" type="checkbox" /> 
                  <label htmlFor="remember-me" className="text-info"><span>Remember me</span></label><br />
                  <input type="submit" name="submit" className="btn btn-info btn-md" value="submit" />
                </div>
                <div id="register-link" className="text-right">
                  <a href="#" className="text-info"></a>
                </div>
              </form>
              {message && <p className="text-center">{message}</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
