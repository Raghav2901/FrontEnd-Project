import { LoremIpsum } from 'react-lorem-ipsum';
import React, { useState } from 'react';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';


function Contact() {
  const [phone, setPhone] = useState('');

  const handlePhoneChange = (value) => {
    setPhone(value);
  };
  return (
    <>
      <section className="getintouch-section mt-5" id="contact">
        <div className="container">
          <div className="bg-border-radius py-5">
            <div className="row">
              <div className="col-lg-12 col-md-12 col-sm-12 text-center">
                <h3 className="getintouch_heading">Get In <span class="mini-heading">Touch</span></h3>
                <p className="getintouch_para">Our dedicated experts are currently standing by to assist you with any of your
                  Shopping Related needs or concerns.</p>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-6 col-md-6 col-sm-12 ps-5 pe-4 ">
                <div className="form-area">
                  <div className="form-inner">
                    <form>
                      <div className="form-group mb-2 py-2 ">
                        <input type="text" className="form-control" placeholder="Your name" value="" />
                      </div>
                      <div className="form-group mb-2 py-2">
                        <PhoneInput
                          country={'in'}
                          value={phone}
                          onChange={handlePhoneChange}
                          inputProps={{
                            name: 'phone',
                            required: true,
                            autoFocus: true,
                          }}
                        />
                      </div>
                      <div className="form-group mb-2 py-2">
                        <input type="text" className="form-control" placeholder="Email" name="name" />
                      </div>

                      <div className="form-group mb-2 py-2">
                         <textarea className="form-control" placeholder="Message"></textarea>
                      </div>
                      <button type="submit" className="btn btn-primary btn-primary-send form-submit">Send</button>
                    </form>
                  </div>
                </div>
              </div>

              <div className="col-lg-5 col-md-5 col-sm-12 me-auto ms-auto  md-padding ">
                <div className="instant-quote-group">
                  <h6 className="instant-quote-heading">NEED AN INSTANT QUOTE ?</h6>
                  <span className="instant-quote-para">Or maybe some free advice?</span>
                  <span className="instant-quote-para">Enter your information in the boxes below and</span>

                  <p className="instant-quote-para">one of our friendly experts will call you very soon</p>
                  <p className="instant-quote-para">Thank you!</p>

                  <p className="instant-quote-para">We’ll contact you momentarily. </p>

                </div>
                <div className="instant-quote-group">
                  <h6 className="instant-quote-heading">CUSTOMER SERVICE</h6>
                  <p className="instant-quote-para">+1 (123) 123-1234 </p>
                  <p className="instant-quote-para"> info@Kulshiy.com </p>


                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer>
        <div className="container">
          <div className="row border-bottom py-5">
            <div className="col-lg-3 col-md-3 col-sm-6">
              <div className="column1">
                <div className="footer-img">
                  <img src="./assets/Group 1171276997.png" alt="" />
                </div>
                <p className="footer-para">
                  Shop now and discover a wide variety of goods at your fingertips. With our advanced shopping platform,
                  excellent customer service, and fast shipping,
                </p>
                <span className="footer-span">your perfect purchase is just a click away!</span>
              </div>
            </div>
            <div className="col-lg-3 col-md-3 col-sm-6 ">
              <div className="footer-menu">
                <ul className="footer-home-list footer-list ">
                  <h6 className="footer-heading">Home</h6>
                  <li className="footer-list-item"><a href="#">Our Mission</a></li>
                  <li className="footer-list-item"><a href="#">Shopping</a></li>
                  <li className="footer-list-item"><a href="#">Services</a></li>
                  <li className="footer-list-item"><a href="#">FAQ</a></li>
                  <li className="footer-list-item"><a href="#">Contact Us</a></li>
                </ul>
              </div>
            </div>
            <div className="col-lg-3 col-md-3 col-sm-6  ">
              <div className="footer-menu">
                <ul className="footer-Contact-list footer-list  ">
                  <h6 className="footer-heading">Contact Us</h6>
                  <li className="footer-list-item"><a href="#">Facebook</a></li>
                  <li className="footer-list-item"><a href="#">Instagram</a></li>
                  <li className="footer-list-item"><a href="#">LinkedIn</a></li>
                  <li className="footer-list-item"><a href="#">WhatsApp (Kulshiy EU)</a></li>
                  <li className="footer-list-item"><a href="#">WhatsApp (Kulshiy turkey)</a></li>
                </ul>
              </div>
            </div>
            <div className="col-lg-3 col-md-12 col-sm-6">
              <h5 className="footer-heading">Get the App</h5>
              <div className="flex-block">
                <div className="footer-playstore-btn">
                  <a className="footer-app-btn" href="#">
                    <img src="./assets/icon-apply.png" alt="" class="footer-icon-btn" />
                    <div className="footer-text-btn">
                      <span className="footer-sm-txt"> Download on the </span>
                      <p className="footer-lg-txt">App Store </p>
                    </div>
                  </a>
                </div>

                <div className="footer-appstore-btn">
                  <a className="footer-play-btn" href="#">
                    <img src="./assets/google-icon.webp" alt="" class="footer-icon-btn" />
                    <div className="footer-text-btn">
                      <span className="footer-sm-txt">GET IT ON</span>
                      <p className="footer-lg-txt">Google Play </p>
                    </div>
                  </a>
                </div>
              </div>

              <div className="followus-block">
                <h6 className="follows-heading">Follow Us</h6>
                <div className="footer-icon-fa mt-3">
                  <i className="fa fa-youtube-play fa-fa-al" aria-hidden="true"></i>
                  <i className="fa fa-facebook fa-fa-al" aria-hidden="true"></i>
                  <i className="fa fa-twitter fa-fa-al" aria-hidden="true"></i>
                  <i className="fa fa-instagram fa-fa-al" aria-hidden="true"></i>
                  <i className="fa fa-linkedin fa-fa-al" aria-hidden="true"></i>
                </div>
              </div>
            </div>
          </div>

          <div className="row my-5">
            <div className="col-lg-6 col-md-6 col-sm-12 ">
              <h6 class="h6-footer">KULSHIY @ 2024. All rights reserved.</h6>
            </div>
            <div className="col-lg-6 col-md-6 col-sm-12">
              <div className="footer-copyright">
                <div><span className="span-footer-text">Terms &amp; Conditions </span></div>
                <div><span className="span-footer-text">Privacy &amp; Policy </span></div>
                <div>
                  <span>
                    <img src="./assets/browser.png" alt="logo" class="img-icon-footer" />
                    <span className="footer-icon-text">ENGLISH </span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>


      </footer>


    </>
  )
}

export default Contact