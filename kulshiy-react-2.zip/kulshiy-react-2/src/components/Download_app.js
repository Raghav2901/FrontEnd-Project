import React from 'react'

function Download_app() {
  return (
   <>
   <section className="goods-section mt-5" id="download-app">
    <div className="container">
      <div className="row">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <div className="goods-container mt-5">
            <h3 className="goods-heading">Discover a wide variety of goods at your fingertips</h3>
            <p className="goods-para">Shop now and discover a wide variety of goods at your fingertips. With our advanced
              shopping platform, excellent customer service, and fast shipping, your perfect purchase is just a click
              away!
            </p>
            <button className="goods_shopnow-btn">
              Shop Now
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section className="shoppinganywhere-section">
    <div className="container">
      <div className="row">
        <div className="col-lg-6 col-md-7 col-sm-12">
          <div className="shopping_anywhere_block">
            <h1 className="shopping-heading">Shopping from
              <span className="heading-color">anywhere</span>
            </h1>
            <p className="shopping-para">Unlock an Unmatched Shopping Experience, Available Anytime, Anywhere
              Get the Kulshiy App for Seamless Shopping on Android and iOS</p>
            <div className="shopping_flex-app">
              <a className="btn-3" href="#">
                <img src="./assets/icon-apply.png" alt="" className="icon-btn-2"/>
                <div className="app-text-btn-2">
                  <span className="text-color"> Download on the <br/>
                    <p className="lg-text">App Store </p>
                  </span>
                </div>
              </a>
              <a className="btn-4" href="#">
                <img src="./assets/google-icon.webp" alt="" className="icon-btn-2"/>
                <div className="play-text-btn-2">
                  <span className="text-color"> GET IT ON<br/>
                    <p className="lg-text">Google Play</p>
                  </span>
                </div>
              </a>

            </div>
          </div>
        </div>
        <div className="col-lg-6 col-md-5 col-sm-12 mt-5">
          <div className="shopping_img_container">
            <img src="./assets/shoppingimg.png" alt=""/>
          </div>
        </div>
      </div>
    </div>
  </section>

   
   
   </>
  )
}

export default Download_app