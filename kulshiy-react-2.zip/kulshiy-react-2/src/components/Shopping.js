import React from 'react'


function Shopping(props) {
  return (
    <>
    <section className="Ourmission-section" id="ourmission">
    <div className="container">
      <div className="row">
        <div className="col-lg-6 col-md-6 col-sm-12 ">
          <div className="mission-image-container">
            <img className="mission-img" src="./assets/shoppingfullimg.png" alt=""/>
          </div>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12 px-5 ">
          <div className="ourmission-block">
            <h2 className="ourmission-head">{props.value}</h2>
            <p className="ourmission-para">
              Our mission is to seamlessly deliver all kinds of goods to our customers, by leveraging advanced
              e-commerce technologies, providing excellent customer service, and upholding the highest quality standards
              in every step of our processes.
            </p>
            <div className="getourapp-block">
              <h5>Get our App</h5>
              <div className="btn-flex">
                  <a className="btn-1" href="#">
                    <img src="./assets/icon-apply.png" alt="" className="icon-btn"/>
                    <div className="app-text-btn">
                      <span className="text-color"> Download on the <br/>
                        <p className="lg-text">App Store </p>
                      </span>
                    </div>
                  </a>
                  <a className="btn-2" href="#">
                    <img src="./assets/google-icon.webp" alt="" className="icon-btn"/>
                    <div className="play-text-btn">
                      <span className="text-color"> GET IT ON<br/>
                        <p className="lg-text">Google Play</p>
                      </span>
                    </div>
                  </a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>

  <section className="our4steps-section">
    <div className="container">
      <div className="row text-center">
        <div className="col-lg-3 col-md-3 col-sm-12  text-center">
          <img className="dotlineimg mt-2rem" src="./assets/Line 45.png" alt=""/>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12 ">
          <h1 className="allisdone-head">All is Done in 4 Steps
            <img className="allisdoneimg" src="./assets/Vector 14.png" alt=""/>
          </h1>
        </div>
        <div className="col-lg-3 col-md-3 col-sm-12 text-center ">
          <img className="dotlineimg mt-2rem" src="./assets/Line 46.png" alt=""/>
        </div>
      </div>
      <div className="row align-center ">
        <div className="col-lg-3 col-md-3 col-sm-12 text-center">
          <div className="group-left">
            <div className="group-icon">
              <img className="circle-img" src="./assets/path3802.png" alt=""/>
            </div>
            <div className="groupicon-info">
              <h1 className=" groupheading groupicon-head">01.</h1>
              <p className="groupicon-para">we purchase the products</p>
            </div>
          </div>
          <div className="vector-icon">
            <img className="vector-img" src="./assets/Vector 43.png" alt=""/>
          </div>
        </div>
        <div className="col-lg-3 col-md-3 col-sm-12 text-center">
          <div className="group">
            <div className="group-right">
              <div className="groupicon-src">
                <img className="circle-img" src="./assets/path3804.png" alt=""/>
              </div>
              <div className="groupicon-info-2">
                <h1 className="groupheading  groupicon-head-2">02.</h1>
                <p className="groupicon-para">we check the products on quality and correct size, colour etc</p>
              </div>
            </div>
            <div className="vector-icon-2">
              <img className="vector-img-2" src="./assets/Vector 45.png" alt=""/>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-3 col-sm-12 text-center">
          <div className="group">
            <div className="group-left-2">
              <div className="group-icon">
                <img className="circle-img" src="./assets/path3806.png" alt=""/>
              </div>
              <div className="groupicon-info-3">
                <h1 className="groupheading  groupicon-head-3">03.</h1>
                <p className="groupicon-para">we ship the goods or return when damaged/incorrect</p>
              </div>
            </div>
            <div className="vector-icon-3">
              <img className="vector-img-3" src="./assets/Vector 44.png" alt=""/>
            </div>
          </div>
        </div>

        <div className="col-lg-3 col-md-3 col-sm-12 text-center">
          <div className="group">
            <div className="group-right-3">
              <div className="groupicon-src">
                <img className="circle-img" src="./assets/path3808.png" alt=""/>
              </div>
              <div className="groupicon-info-4">
                <h1 className="groupheading  groupicon-head-4">04.</h1>
                <p className="groupicon-para">Properly deliver it to your doorstep with care </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row mt-4 ms-auto me-auto text-center">
        <div className="col-lg-12 col-md-12 col-sm-12 mt-5">
          <button className="shopnow-btn">
            Shop Now
          </button>
        </div>
      </div>
    </div>
  </section>
  </>
  )
}

export default Shopping