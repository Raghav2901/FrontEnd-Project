import React  from 'react';
import { Link, useLocation } from 'react-router-dom';
import "./login.css"


function Navbar() {
  const location = useLocation();

  const isActive = (path) => {
      return location.pathname === path ? 'active' : '';
  };


  return (
    <>

<div className="header-menu style-one bg-white ">
    <div className="flex-between h-80">
      <nav className="navbar container navbar-expand-lg navbar-light px-3">
        <Link className="navbar-brand fw-bold" to="#"><img className="logo-img" src="./assets/logo-header.png" alt="logo"></img> </Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="navbar-collapse collapse show flex_nav  " id="navbarSupportedContent">

          <ul className="navbar-nav ms-text mb-2 mb-lg-0 ms-left">
            <li className="nav-item padding_1400  active">
            <Link className={`nav-link nav-link-fade-up ${isActive('/')}`} aria-current="page" to="/">
            Home
            </Link>
            </li>

            <li className="nav-item">
            <Link className={`nav-link nav-link-fade-up ${isActive('/shopping')}`} to="/shopping">
              Shopping
            </Link>
            </li>

            <li className="nav-item">
              <Link className={`nav-link nav-link-fade-up ${isActive('/services')}`} to="/services">
                Services
             </Link>
            </li>

            <li classn="nav-item">
            <Link className={`nav-link nav-link-fade-up ${isActive('/download-app')}`} to="/download-app">
                 Download App   
            </Link>    
            </li>

            <li className="nav-item">
            <Link className={`nav-link nav-link-fade-up ${isActive('/faq')}`} to="/faq">   
                Faq
             </Link>
            </li>
             </ul>
           
       

          <Link className="nav-img-link" to="#"><img className="header-icon" src="./assets/header-icon.png" alt="logo"/> </Link>
          <Link className="nav-link nav-button-text" to ="/"> ENGLISH</Link>
            <div className="auth-buttons">
              <Link className="btn btn-outline-dark fw-bold nav-btn" to="/loginpage">
                Login
              </Link>
              <Link className="btn btn-dark fw-bold nav-btn" to="/registerpage">
                Register
              </Link>
            </div>
          <button className="btn btn-outline-dark fw-bold" type="submit">
            <Link className="nav-contact" to="/contact">Contact Us</Link>
          </button>
        </div>
      </nav>
    </div>
  </div>

</>

)
}

export default Navbar;