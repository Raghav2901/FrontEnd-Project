import React from 'react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Shopping from './Shopping';

 


function Home() {
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1500,
    responsive: [
      { breakpoint: 1400, settings: { slidesToShow: 8 } },
      { breakpoint: 1200, settings: { slidesToShow: 6 } },
      { breakpoint: 992, settings: { slidesToShow: 5 } },
      { breakpoint: 768, settings: { slidesToShow: 4 } },
      { breakpoint: 576, settings: { slidesToShow: 3 } },
      { breakpoint: 480, settings: { slidesToShow: 2 } },
      { breakpoint: 320, settings: { slidesToShow: 1 } },
    ]
  };
  return (
    <>

      <section className="shopping-solution" id="shopping">
        <div className="container">
          <div className="row mt-5">
            <div className="col-lg-6 col-md-6 col-sm-12 ">
              <div className="shoppingsolution-block">
                <div className="smallpara">
                  <p className="kulshiy-para">Kulshiy at your doorstep</p>
                </div>
                <div className="bigpara">
                  <h1 className="shoppingpara"><Shopping value = "Our Mission"/></h1>
                </div>
                <div className="shoppingexppara">
                  <p>Unlock an Unmatched Shopping Experience, Available Anytime, Anywhere
                    Get the Kulshiy App for Seamless Shopping on Android and iOS</p>
                </div>
                <div className="btn-block">
                  <button className="shopnow-btn btn">
                    Shop Now
                  </button>
                  <button className="viewdemo-btn btn">
                    <i className="fa fa-play-circle-o" aria-hidden="true"></i> View Demo
                  </button>
                </div>
              </div>
            </div>
            <div className="col-lg-6 col-md-6 col-sm-12 ">
              <div className="image-container">
                <div className="trendbgimage-block">
                  <img src="./assets/Frame 1171277059.png" alt="frame-logo" />
                </div>
                <div className="file1-img-block">
                  <img src="./assets/file 1.png" alt="file-logo" />
                </div>
                <div className="group1-img-block">
                  <img src="./assets/Group 11.png" alt="group-logo" />
                </div>
                <div className="trendingimg-block">
                  <img src="./assets/Main Headline.png" alt="headline-logo" />
                </div>
                <div className="arrow-img">
                  <img className="arrow-icon" src="./assets/Arrow 1.png" alt="arrow-logo" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      
       <section className="slider-bg mt-5">
      <div className="container">
        <div className="row">
          <div className="col-lg-12 col-md-12 col-sm-12 col-carousel">
            <Slider {...settings}>
              <div className="item"><img src="./assets/Group shein.png" alt="shein-logo" className="group-img" /></div>
              <div className="item"><img src="./assets/Group amazon.png" alt="amazon-logo" className="group-img" /></div>
              <div className="item"><img src="./assets/Group zalando.png" alt="zalando-logo" className="group-img" /></div>
              <div className="item"><img src="./assets/Group ebay.png" alt="ebay-logo" className="group-img" /></div>
              <div className="item"><img src="./assets/Group aliexpress.png" alt="aliexpress-logo" className="group-img" /></div>
              <div className="item"><img src="./assets/Group gucci.png" alt="gucci-logo" className="group-img" /></div>
            </Slider>
          </div>
        </div>
      </div>
    </section>
    </>
  )
}

export default Home;