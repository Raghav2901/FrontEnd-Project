import React from 'react'

function Faq() {
  return (
    <section className="asked_question_section mt-5" id="faq">
    <div className="container">
      <div className="row  py-4">
        <div className="col-lg-10 col-md-12 col-sm-12 me-auto ms-auto text-align: center">
          <div className="asked_question_block">
            <h1 className="asked_question_heading">Frequently asked questions</h1>
            <p className="asked_question_para">Our comprehensive FAQ section is here to provide you with detailed answers to
              all your questions. A wealth of information regarding Kulshiy's operations, shipping policies, quality
              control measures, and more.</p>
          </div>
        </div>
        <div className="col-lg-9  col-md-12 col-sm-12 mt-4 me-auto ms-auto">
          <div className="accordion accordion-flush" id="accordionFlushExample">
            <div className="accordion-item accordion-border-bottom mb-3">
              <h2 className="accordion-header" id="flush-headingOne">
                <button className="accordion-button accordion-button-bg collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                  <h6 className="h6-according"> How does Kulshiy ensure the quality of products purchased
                    through its platform? </h6>
                </button>
              </h2>
              <div id="flush-collapseOne" className="accordion-collapse collapse" aria-labelledby="flush-headingOne"
                data-bs-parent="#accordionFlushExample">
                <div className="accordion-body">
                  <p className="p-text-accordion">Providing information on shipping methods, estimated
                    delivery times, and any associated costs can help customers plan their purchases
                    accordingly and manage their expectations regarding delivery.</p>
                </div>
              </div>
            </div>
            <div className="accordion-item accordion-border-bottom mb-3">
              <h2 className="accordion-header" id="flush-headingTwo">
                <button className="accordion-button collapsed accordion-button-bg" type="button" data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                  <h6 className="h6-according"> What are Kulshiy's shipping options and delivery times?
                  </h6>
                </button>
              </h2>
              <div id="flush-collapseTwo" className="accordion-collapse collapse" aria-labelledby="flush-headingTwo"
                data-bs-parent="#accordionFlushExample">
                <div className="accordion-body">
                  <p className="p-text-accordion">Providing information on shipping methods, estimated
                    delivery times, and any associated costs can help customers plan their purchases
                    accordingly and manage their expectations regarding delivery.</p>
                </div>
              </div>
            </div>
            <div className="accordion-item accordion-border-bottom mb-3">
              <h2 className="accordion-header" id="flush-headingThree">
                <button className="accordion-button collapsed accordion-button-bg" type="button" data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                  <h6 className="h6-according"> What is Kulshiy's return and refund policy? </h6>
                </button>
              </h2>
              <div id="flush-collapseThree" className="accordion-collapse collapse" aria-labelledby="flush-headingThree"
                data-bs-parent="#accordionFlushExample">
                <div className="accordion-body">
                  <p className="p-text-accordion">Providing information on shipping methods, estimated
                    delivery times, and any associated costs can help customers plan their purchases
                    accordingly and manage their expectations regarding delivery.</p>
                </div>
              </div>
            </div>
            <div className="accordion-item accordion-border-bottom mb-3">
              <h2 className="accordion-header" id="flush-headingfour">
                <button className="accordion-button collapsed accordion-button-bg" type="button" data-bs-toggle="collapse"
                  data-bs-target="#flush-collapsefour" aria-expanded="false" aria-controls="flush-collapsefour">
                  <h6 className="h6-according"> Does Kulshiy offer customer support, and how can customers
                    get in touch? </h6>
                </button>
              </h2>
              <div id="flush-collapsefour" className="accordion-collapse collapse" aria-labelledby="flush-headingfour"
                data-bs-parent="#accordionFlushExample">
                <div className="accordion-body">
                  <p class="p-text-accordion">Providing information on shipping methods, estimated
                    delivery times, and any associated costs can help customers plan their purchases
                    accordingly and manage their expectations regarding delivery.</p>
                </div>
              </div>
            </div>
            <div className="accordion-item accordion-border-bottom mb-3">
              <h2 className="accordion-header" id="flush-headingfive">
                <button className="accordion-button collapsed  accordion-button-bg " type="button" data-bs-toggle="collapse"
                  data-bs-target="#flush-collapsefive" aria-expanded="false" aria-controls="flush-collapsefive">
                  <h6 className="h6-according"> What measures does Kulshiy take to protect customer data
                    and privacy? </h6>
                </button>
              </h2>
              <div id="flush-collapsefive" className="accordion-collapse collapse" aria-labelledby="flush-headingfive"
                data-bs-parent="#accordionFlushExample">
                <div className="accordion-body">
                  <p className="p-text-accordion">Providing information on shipping methods, estimated
                    delivery times, and any associated costs can help customers plan their purchases
                    accordingly and manage their expectations regarding delivery.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  )
}

export default Faq