import React, { useState } from 'react';
import axios from 'axios';
import "./register.css"

function Registerpage() {

   const [name, setName] = useState("");
   const [phone, setPhone] = useState("");
   const [email, setEmail] = useState("");
   const [password, setPassword] = useState("");
   const [password_confirmation, setconfirmPassword] = useState("");
   const [agree, setAgree] = useState("");
   const [message, setMessage] = useState("")

   const handleSubmit = async (e) => {
      e.preventDefault();
          try{
                const res = await axios.post("https://kulshiy.com/staging/api/store-register",{

                name: name,
                phone: phone,
                password: password,
                agree: agree,
                password_confirmation: password_confirmation,
                email :email,
                });
            

              if(res.status ===200){
                  setMessage("Login Successful")

              }else{
                setMessage(res.data.message || 'Some error occurred');
              }
            } catch (err) {
              console.log(err);
              setMessage('Server error');
            }
          };

            



  return (
       <>
          <div className="register-container">
      <h2 className="register-title">Register</h2>
      <form className="register-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            value={name}
            name="name" 
            onChange={(e) => setName(e.target.value)}
            className="form-control"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone</label>
          <input
            type="tel"
            id="phone"
            value={phone}
            name="phone"
            onChange={(e) => setPhone(e.target.value)}
            className="form-control"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={email}
            name="email"
            onChange={(e) => setEmail(e.target.value)}
            className="form-control"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="form-control"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="confirmpassword">Confirm Password</label>
          <input
            type="password"
            id="password"
            name="password_confirmation"
            value={password_confirmation}
            onChange={(e) => setconfirmPassword(e.target.value)}
            className="form-control"
            required
          />
        </div>
        <div className="form-group">
          <input
            type="checkbox"
            id="agree"
            checked={agree}
            value={"1"}
            onChange={(e) => setAgree(e.target.checked)}
            className="form-checkbox"
            required
          />
          <label htmlFor="agree">I agree to the terms and conditions</label>
        </div>
        <button type="submit" className="btn btn-primary">Register</button>
      </form>
      {message && <p className="message">{message}</p>}
    </div>
       
       </>
  )
}


export default Registerpage