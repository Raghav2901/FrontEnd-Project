import React, { useState, useEffect } from "react";

function Services() {
    const [services, setServices] = useState([]);

    const fetchServicesData = () => {
        fetch("http://13.201.38.158/api/get-services")
            .then((response) => response.json())
            .then((response) => {
                setServices(response.data);

            });

    };

    useEffect(() => {
        fetchServicesData();
    }, []);

    return (
        <section className="services-section" id="services">
            <div className="container">
                <div className="row">
                    <h3 className="services-head">Services We
                        <span className="services-span">Provide</span>
                    </h3>

                    {services.map((service) => (
                        <div className="col-lg-4 col-md-6 col-sm-12 mb-5">
                            <div className="card-bg mb-4">
                                <div className="icon-box align-center">
                                    <div className="servicesimg-container">
                                        <img className="services-img" src={service.image} />
                                    </div>
                                    <h3 className="main-heading">{service.title}</h3>
                                    <p className="services-para">{service.description}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}

export default Services;
