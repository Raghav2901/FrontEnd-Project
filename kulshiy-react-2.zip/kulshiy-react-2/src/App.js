import React from "react";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Services from "./components/Services";
import Download_app from "./components/Download_app";
import Faq from "./components/Faq";
import Shopping from "./components/Shopping";
import Contact from "./components/Contact";
import Loginpage from "./components/loginpage"; 
import Dashboard from "./components/dashboard";
import Registerpage from "./components/registerationPage";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PrivateRoute from "./components/PrivateRoute";
import { AuthProvider } from "./components/AuthContext";

function App() {
  return (

      <AuthProvider>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shopping" element={<Shopping />} />
          <Route path="/services" element={<Services />} />
          <Route path="/download-app" element={<Download_app />} />
          <Route path="/faq" element={<Faq />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/loginpage" element={<Loginpage />} />
          <Route path="/registerPage" element={<Registerpage />} />
          <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
        </Routes>
      </AuthProvider>

  );
}

export default App;
